# Approval: POST /api/appointments accepts a second appointment for the same patie

Run 20261004-post-api-appointments-accepts-b0f9 · risk **medium** · bugfix · size S · cost so far $0.98

## Your request (word for word)
> POST /api/appointments accepts a second appointment for the same patient that overlaps one they already have with
> another doctor. A patient can't be in two places at once: refuse the overlapping booking with 409 Conflict, the
> same way a doctor's overlapping booking is refused today.
> 


## Your answers
- Q-1 Should patient-side double-booking also be blocked at the database level when two requests arrive at the same moment? The doctor side has a unique index plus a fallback that catches the save error. The patient index (IX_Appointments_Patient_StartTime) is not unique, so matching the doctor side would need a schema change. → **A check in the application code is enough, the same way the doctor check works today. No database, index or migration changes.**

Other assumptions: ASM-1 What error code and message should the patient overlap conflict use? → assumed: Reuse code "Appointment.Conflict" with message "Patient has a conflicting appointment during the requested time"; ASM-2 If a request overlaps both the doctor's schedule and the patient's schedule, which conflict should be reported? → assumed: Doctor check first (existing behaviour unchanged), then the patient check

## Requirements
- **REQ-1** (ADDED) When POST /api/appointments is submitted for a patient who already has a Scheduled appointment whose time range overlaps the requested start and end times (existing.StartUtc < requested end AND existing.EndUtc > requested start), and the requested doctor has no Scheduled appointment overlapping that time range, the BookAppointment handler shall return a 409 Conflict response with error code "Appointment.Conflict" and message "Patient has a conflicting appointment during the requested time".
  - AC-1.1 [unit] Given A patient already has a Scheduled appointment with Doctor A from 10:00 to 10:30 UTC, and Doctor B has no Scheduled appointment between 10:15 and 10:45 UTC; when BookAppointment.Handler.Handle is called with the same PatientId, DoctorId B, Start 10:15 and End 10:45 UTC; then the handler returns a failure result of type Conflict with code "Appointment.Conflict" and description "Patient has a conflicting appointment during the requested time"
  - AC-1.2 [api] Given A prior successful POST /api/appointments created an appointment for patient X with doctor A from 10:00 to 10:30 UTC, and doctor B has no appointment between 10:15 and 10:45 UTC; when POST /api/appointments is sent for patient X with doctor B, Start 10:15 and End 10:45 UTC; then the response status is 409 Conflict and the ProblemDetails title is "Patient has a conflicting appointment during the requested time"
  - AC-1.3 [unit] Given A patient has an existing Scheduled appointment ending exactly at 10:30 UTC; when BookAppointment.Handler.Handle is called for the same patient with a different doctor and a requested Start of exactly 10:30 UTC (back-to-back, no overlap); then the handler does not return an "Appointment.Conflict" error for the patient and the booking proceeds (consistent with the exclusive-bound overlap semantics used for the doctor check)
  - AC-1.4 [unit] Given A patient has a Cancelled appointment that overlaps the requested time with a different doctor, and no Scheduled appointment overlaps; when BookAppointment.Handler.Handle is called for that patient and time range; then the handler does not return a patient "Appointment.Conflict" error, because only Scheduled appointments count toward the overlap check
- **REQ-2** (ADDED) If a booking request overlaps both the doctor's schedule and the requesting patient's schedule, then the BookAppointment handler shall return the existing doctor conflict error ("Doctor has a conflicting appointment during the requested time") rather than the new patient conflict error.
  - AC-2.1 [unit] Given Doctor A already has a Scheduled appointment overlapping the requested time, and patient X also already has a separate Scheduled appointment (with a different doctor) overlapping the requested time; when BookAppointment.Handler.Handle is called requesting doctor A for patient X at the overlapping time; then the handler returns a Conflict result with code "Appointment.Conflict" and description "Doctor has a conflicting appointment during the requested time", not the patient conflict message

Not changing: Database schema, index, or migration changes to enforce patient overlap uniqueness at the data layer (Q-1).; A DbUpdateException/unique-constraint race-condition fallback for patient overlaps, since no unique index exists for (PatientId, StartUtc, EndUtc) and none is being added (Q-1).; Any UI changes, since the request does not touch a screen (touchesUi: false).

## Files the plan will touch (1)
- src/Application/Scheduling/BookAppointment.cs

## Will also affect (found by code search, not in the plan)
- tests/Application.UnitTests/Scheduling/BookAppointmentValidatorTests.cs (tests): test BookAppointment
- tests/Application.UnitTests/Scheduling/CompleteAppointmentValidatorTests.cs (tests): test Validator
- src/Api/Program.cs (callers): uses MapHealthcareEndpoints
- src/Application/Common/ValidationFilter.cs (callers): uses MinimalApiProblemHelper
- src/Application/Scheduling/CancelAppointment.cs (callers): uses Command
- src/Application/Scheduling/CompleteAppointment.cs (callers): uses Command
- src/Application/Scheduling/GetAppointmentById.cs (callers): uses Endpoint
- …and 3 more (see the impact artifact)

## Plan
Options: OPT-1 (chosen): Add a second AnyAsync query on PatientId in BookAppointment.Handler right after the doctor overlap check. It returns Error.Conflict("Appointment.Conflict", "Patient has a conflicting appointment during the requested time"). | OPT-2: Replace both checks with one query that fetches overlapping Scheduled appointments where DoctorId == request.DoctorId OR PatientId == request.PatientId. Decide in memory which error to return, doctor first. | OPT-3: Move overlap rules into a domain/application service, for example ISchedulingConflictChecker, used by the handler.
Decision: Decision: add a patient overlap AnyAsync check in BookAppointment.Handler right after the existing doctor check (OPT-1).
Why: it mirrors the existing doctor-check pattern and the exclusive-bound/Scheduled-only semantics. Running it after the doctor check makes the doctor conflict win (REQ-2, ASM-2).
HTTP 409 comes from MinimalApiProblemHelper's existing ErrorType.Conflict mapping, so no endpoint changes are needed. The handler returns the domain error (this resolves the critic's rubric-1 finding).
No schema, index, migration or DbUpdateException fallback for patients. The check-then-act race window is accepted, as with the doctor check (Q-1, out of scope).
Rejected: single combined OR query (OPT-2) and a new conflict-checker service (OPT-3). Both add complexity without any requirement asking for it.
- TASK-1 Add patient overlap check to BookAppointment.Handler after the doctor overlap check → REQ-1, REQ-2; must pass AC-1.1, AC-1.2, AC-1.3, AC-1.4, AC-2.1

## Critic findings (3)
- [medium] REQ-1 REQ-1 says the BookAppointment handler shall return a "409 Conflict response", but the grounded behaviour shows the handler returns domain errors and only the endpoint/MinimalApiProblemHelper maps ErrorType.Conflict to an HTTP 409 response.
- [low] REQ-1 AC-1.3 says the booking proceeds for a back-to-back patient appointment without stating that the patient and doctor exist and the requested doctor has no overlapping Scheduled appointment, so the acceptance condition can fail for unrelated existing validation/conflict paths.
- [low] REQ-1 AC-1.4 says the handler does not return a patient conflict when only a Cancelled appointment overlaps, but it does not constrain doctor availability or entity existence, so the observable result can be another error rather than demonstrating the cancelled-patient path.

Round trip: the spec restated back matches your request (nothing dropped, nothing added).

## Decide
  factory approve 20261004-post-api-appointments-accepts-b0f9 <hash> --note "your risk note"
  factory reject  20261004-post-api-appointments-accepts-b0f9 <hash> --reason "why"

Card hash: aebfe0fe