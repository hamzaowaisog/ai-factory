# Questions before the spec (round 1)

Run 20261004-post-api-appointments-accepts-b0f9. Your request:
> POST /api/appointments accepts a second appointment for the same patient that overlaps one they already have with
> another doctor. A patient can't be in two places at once: refuse the overlapping booking with 409 Conflict, the
> same way a doctor's overlapping booking is refused today.
> 

**Q-1** Should patient-side double-booking also be blocked at the database level when two requests arrive at the same moment? The doctor side has a unique index plus a fallback that catches the save error. The patient index (IX_Appointments_Patient_StartTime) is not unique, so matching the doctor side would need a schema change.
  A. Only add the in-handler patient overlap check; no new index, migration or save-error fallback   ← recommended: The request asks for the 409 rejection. The doctor's own overlap check also leaves the same race window open, so this needs no schema change.
  B. Add a unique index on (PatientId, StartUtc, EndUtc) with a migration, and catch its save error as a 409 the way the doctor side does
  C. Add a database exclusion constraint (or equivalent) that blocks overlapping time ranges per patient, and catch its save error as a 409
  (why it matters: Decides whether a schema migration happens and whether duplicate rows can still be written when two requests race.)

Assumed unless you say otherwise:
- ASM-1: What error code and message should the patient overlap conflict use? → assumed: Reuse code "Appointment.Conflict" with message "Patient has a conflicting appointment during the requested time"
- ASM-2: If a request overlaps both the doctor's schedule and the patient's schedule, which conflict should be reported? → assumed: Doctor check first (existing behaviour unchanged), then the patient check

Answer with letters or your own words:
  factory answer 20261004-post-api-appointments-accepts-b0f9 b374b997 Q-1=A
  (use quotes for words: Q-1="only for guest checkouts")

Card hash: b374b997