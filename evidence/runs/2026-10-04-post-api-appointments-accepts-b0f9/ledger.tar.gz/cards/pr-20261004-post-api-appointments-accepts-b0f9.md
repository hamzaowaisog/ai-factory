# factory: When POST /api/appointments is submitted for a patient who a

## What was asked
> POST /api/appointments accepts a second appointment for the same patient that overlaps one they already have with
> another doctor. A patient can't be in two places at once: refuse the overlapping booking with 409 Conflict, the
> same way a doctor's overlapping booking is refused today.
> 

## Requirements → tests
- **REQ-1** When POST /api/appointments is submitted for a patient who already has a Scheduled appointment whose time range overlaps the requested start and end times (existing.StartUtc < requested end AND existing.EndUtc > requested start), and the requested doctor has no Scheduled appointment overlapping that time range, the BookAppointment handler shall return a 409 Conflict response with error code "Appointment.Conflict" and message "Patient has a conflicting appointment during the requested time".
  - AC-1.1 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.BookAppointmentHandlerTests.AC_1_1_ReturnsPatientConflictWhenPatientDoubleBooked`
  - AC-1.2 (HTTP test + probe): `verticalslicearchitecture.application.integrationtests::VerticalSliceArchitecture.Application.IntegrationTests.AppointmentApiTests.AC_1_2_ReturnsConflictWhenPatientHasOverlappingAppointmentWithDifferentDoctor`
  - AC-1.3 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.BookAppointmentHandlerTests.AC_1_3_AllowsBackToBackPatientAppointmentStartingExactlyAtPriorEnd`
  - AC-1.4 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.BookAppointmentHandlerTests.AC_1_4_IgnoresCancelledAppointmentsForPatientConflictCheck`
- **REQ-2** If a booking request overlaps both the doctor's schedule and the requesting patient's schedule, then the BookAppointment handler shall return the existing doctor conflict error ("Doctor has a conflicting appointment during the requested time") rather than the new patient conflict error.
  - AC-2.1 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.BookAppointmentHandlerTests.AC_2_1_ReturnsDoctorConflictNotPatientConflictWhenBothOverlap`

## Tasks
- TASK-1 Add patient overlap check to BookAppointment.Handler after the doctor overlap check (REQ-1, REQ-2)

## Checks the factory ran itself
- 35 tests in a sealed container; 35 passed; no new failures vs the base branch
- Acceptance tests were written first, failed on the old code twice, then locked
- ⚠ Single model family: tests written by claude-sonnet-5, code by claude-sonnet-5 (both anthropic). A second-vendor coding runner isn't built yet.
- Review: 0 non-blocking findings
- Security review (OWASP Top 10): nothing found

Cost: $2.50 · Run: `20261004-post-api-appointments-accepts-b0f9` · Evidence manifest: `a60c4a4f35a6a0da799c72f96bff58e9219e19a31e25dbaeee17daf70a32b239`