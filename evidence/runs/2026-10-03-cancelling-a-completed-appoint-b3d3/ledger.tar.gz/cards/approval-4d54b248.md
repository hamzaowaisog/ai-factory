# Approval: Cancelling a completed appointment, or completing a cancelled one, ret

Run 20261003-cancelling-a-completed-appoint-b3d3 · risk **low** · bugfix · size M · cost so far $1.11

## Your request (word for word, from typed prompt)
> Cancelling a completed appointment, or completing a cancelled one, returns 400 Bad Request. The request itself is valid; the appointment's current state forbids it, so the API should answer 409 Conflict with the same error message. A missing or too-long reason or notes must still return 400.


Other assumptions: ASM-1 In Appointment.Complete, the Cancelled-state check runs before the notes-length check. Over HTTP this already returns 400, because the validator rejects notes over 1024 characters before the handler runs. Should the domain's check order also change, so that over-long notes on a cancelled appointment throw ArgumentException (400) even when the validator is bypassed? → assumed: No: leave the domain order alone. The validator already gives 400 at the API.

## Requirements
- **REQ-1** (MODIFIED) When a client requests POST /api/appointments/{appointmentId}/cancel for an appointment whose current Status is Completed, the CancelAppointment API shall respond with 409 Conflict carrying the message "Cannot cancel a completed appointment".
  - AC-1.1 [unit] Given an Appointment aggregate whose Status is Completed; when CancelAppointment.Handler.Handle is invoked directly with a Command carrying a valid, non-empty Reason within the length limit; then the returned ErrorOr result contains a single Error of Type Conflict with code "Appointment.CannotCancel" and description "Cannot cancel a completed appointment"
  - AC-1.2 [api] Given an appointment that has already been completed via POST /api/appointments/{appointmentId}/complete; when POST /api/appointments/{appointmentId}/cancel is called with a valid reason; then the HTTP response status is 409 Conflict and the problem response body's detail/message equals "Cannot cancel a completed appointment"
- **REQ-2** (MODIFIED) When a client requests POST /api/appointments/{appointmentId}/complete for an appointment whose current Status is Cancelled, the CompleteAppointment API shall respond with 409 Conflict carrying the message "Cannot complete a cancelled appointment".
  - AC-2.1 [unit] Given an Appointment aggregate whose Status is Cancelled; when CompleteAppointment.Handler.Handle is invoked directly with a Command carrying Notes within the length limit (or null); then the returned ErrorOr result contains a single Error of Type Conflict with code "Appointment.CannotComplete" and description "Cannot complete a cancelled appointment"
  - AC-2.2 [api] Given an appointment that has already been cancelled via POST /api/appointments/{appointmentId}/cancel; when POST /api/appointments/{appointmentId}/complete is called with valid notes; then the HTTP response status is 409 Conflict and the problem response body's detail/message equals "Cannot complete a cancelled appointment"
- **REQ-3** (MODIFIED) The OpenAPI metadata for the CompleteAppointment and CancelAppointment endpoints shall declare a 409 Conflict response in addition to the existing 200, ValidationProblem, and 404 responses.
  - AC-3.1 [api] Given the application's generated OpenAPI document; when the document is retrieved (e.g. GET /swagger/v1/swagger.json); then the responses listed for POST /api/appointments/{appointmentId}/cancel and POST /api/appointments/{appointmentId}/complete each include a 409 entry alongside 200, 400 and 404
- **REQ-4** (MODIFIED) If a cancel or complete request's reason or notes is missing (for cancel) or exceeds the configured maximum length, then the API shall respond with 400 Bad Request regardless of the appointment's current state.
  - AC-4.1 [unit] Given a CancelAppointment.Command with an empty Reason; when CancelAppointment.Validator validates the command directly; then validation fails with the message "Cancellation reason is required"
  - AC-4.2 [unit] Given a CancelAppointment.Command with a Reason longer than 512 characters; when CancelAppointment.Validator validates the command directly; then validation fails with the message "Cancellation reason cannot exceed 512 characters"
  - AC-4.3 [unit] Given a CompleteAppointment.Command with Notes longer than 1024 characters; when CompleteAppointment.Validator validates the command directly; then validation fails with the message "Notes cannot exceed 1024 characters"
  - AC-4.4 [api] Given an appointment in any status (including Completed or Cancelled); when POST /api/appointments/{appointmentId}/cancel is called with an empty reason; then the HTTP response status is 400 Bad Request, not 409

Not changing: Changing the order of the Cancelled-state check and the notes-length check inside Appointment.Complete (ASM-1); Any change to BookAppointment's existing Error.Conflict usage for doctor time-overlap, which already returns 409 and is unaffected by this fix; Any change to the optimistic-concurrency Error.Conflict path (DbUpdateConcurrencyException) in the cancel/complete handlers, which already returns 409 and is unaffected by this fix

## Files the plan will touch (4)
- src/Application/Common/MinimalApiProblemHelper.cs
- src/Application/Scheduling/AppointmentEndpoints.cs
- src/Application/Scheduling/CancelAppointment.cs
- src/Application/Scheduling/CompleteAppointment.cs

## Plan
Options: OPT-A (chosen): Change the two handler catch blocks from Error.Validation to Error.Conflict for InvalidOperationException, add ProducesProblem(409) to both endpoints, and also set ProblemDetails.Detail in the existing problem helper so the domain message appears in the body. | OPT-B: Add guard methods to Appointment (e.g. CanCancel/CanComplete) or have the handlers check Status before calling the domain, and return Error.Conflict without relying on exceptions. | OPT-C: Add a domain-specific exception type (e.g. InvalidAppointmentStateException), throw it from the domain and map it centrally.
Decision: Context: cancel and complete handlers turn domain InvalidOperationException (forbidden state transition) into Error.Validation, so the response is 400 instead of 409.
Decision: return Error.Conflict for the InvalidOperationException path and keep ArgumentException as Validation (400), add ProducesProblem(409) to both endpoints, and put the description into ProblemDetails.Detail as well as Title.
Input rules stay in the FluentValidation validators (ValidationFilter/ValidationBehaviour run before the handler), so missing or over-long input gives 400 whatever the state. The domain is unchanged (ASM-1).
Rejected: pre-checking status in the handlers, or adding a new exception type. Both duplicate domain rules or widen scope for no visible gain.
Consequence: the helper's 409 mapping is reused, and 404/409 problem bodies now also carry a detail field (additive).
- TASK-1 Map domain state-transition refusals to Error.Conflict in cancel/complete handlers → REQ-1, REQ-2, REQ-4; must pass AC-4.1, AC-4.2, AC-4.3, AC-4.4
- TASK-2 Declare 409 Conflict in OpenAPI metadata for complete/cancel endpoints → REQ-3; must pass AC-3.1
- TASK-3 Include error description as ProblemDetails.Detail for non-validation problems → REQ-1, REQ-2; must pass AC-1.1, AC-1.2, AC-2.1, AC-2.2

## Critic findings (3)
- [medium] REQ-4 AC-2.1 explicitly allows null Notes while REQ-4 narrows the missing-input 400 rule to cancel only, which leaves the source requirement that a missing reason or notes must still return 400 unaddressed for CompleteAppointment.
- [medium] REQ-4 REQ-4 promises the API returns 400 for over-long reason or notes regardless of appointment state, but its acceptance criteria only check over-length inputs by direct validator unit tests and include no public API case for over-long notes on a cancelled appointment or over-long reason on a completed appointment.
- [low] REQ-4 AC-4.2 and AC-4.3 hardcode the 512 and 1024 limits and exact message text even though the requirement describes a configured maximum length backed by SchedulingPolicies constants.

Round trip: the spec restated back matches your request (nothing dropped, nothing added).

## Decide
  factory approve 20261003-cancelling-a-completed-appoint-b3d3 <hash> --note "your risk note"
  factory reject  20261003-cancelling-a-completed-appoint-b3d3 <hash> --reason "why"

Card hash: 4d54b248