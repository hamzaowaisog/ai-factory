# factory: When a client requests POST /api/appointments/{appointmentId

## What was asked
From: typed prompt

> Cancelling a completed appointment, or completing a cancelled one, returns 400 Bad Request. The request itself is valid; the appointment's current state forbids it, so the API should answer 409 Conflict with the same error message. A missing or too-long reason or notes must still return 400.

## Requirements → tests
- **REQ-1** When a client requests POST /api/appointments/{appointmentId}/cancel for an appointment whose current Status is Completed, the CancelAppointment API shall respond with 409 Conflict carrying the message "Cannot cancel a completed appointment".
  - AC-1.1 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.CancelAppointmentHandlerTests.AC_1_1_ReturnsConflictWhenAppointmentCompleted`
  - AC-1.2 (HTTP test + probe): `verticalslicearchitecture.application.integrationtests::VerticalSliceArchitecture.Application.IntegrationTests.AppointmentStatusTransitionApiTests.AC_1_2_CancelCompletedAppointmentReturnsConflict`
- **REQ-2** When a client requests POST /api/appointments/{appointmentId}/complete for an appointment whose current Status is Cancelled, the CompleteAppointment API shall respond with 409 Conflict carrying the message "Cannot complete a cancelled appointment".
  - AC-2.1 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.CompleteAppointmentHandlerTests.AC_2_1_ReturnsConflictWhenAppointmentCancelled`
  - AC-2.2 (HTTP test + probe): `verticalslicearchitecture.application.integrationtests::VerticalSliceArchitecture.Application.IntegrationTests.AppointmentStatusTransitionApiTests.AC_2_2_CompleteCancelledAppointmentReturnsConflict`
- **REQ-3** The OpenAPI metadata for the CompleteAppointment and CancelAppointment endpoints shall declare a 409 Conflict response in addition to the existing 200, ValidationProblem, and 404 responses.
  - AC-3.1 (HTTP test + probe): `verticalslicearchitecture.application.integrationtests::VerticalSliceArchitecture.Application.IntegrationTests.AppointmentStatusTransitionApiTests.AC_3_1_OpenApiListsConflictForCancelAndComplete`
- **REQ-4** If a cancel or complete request's reason or notes is missing (for cancel) or exceeds the configured maximum length, then the API shall respond with 400 Bad Request regardless of the appointment's current state.
  - AC-4.1 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.CancelAppointmentValidatorTests.AC_4_1_FailsWhenReasonEmpty`
  - AC-4.2 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.CancelAppointmentValidatorTests.AC_4_2_FailsWhenReasonExceeds512Characters`
  - AC-4.3 (unit test): `verticalslicearchitecture.application.unittests::VerticalSliceArchitecture.Application.UnitTests.Scheduling.CompleteAppointmentValidatorTests.AC_4_3_FailsWhenNotesExceed1024Characters`
  - AC-4.4 (HTTP test + probe): `verticalslicearchitecture.application.integrationtests::VerticalSliceArchitecture.Application.IntegrationTests.AppointmentStatusTransitionApiTests.AC_4_4_CancelWithEmptyReasonReturnsBadRequestInAnyStatus`

## Tasks
- TASK-1 Map domain state-transition refusals to Error.Conflict in cancel/complete handlers (REQ-1, REQ-2, REQ-4)
- TASK-2 Declare 409 Conflict in OpenAPI metadata for complete/cancel endpoints (REQ-3)
- TASK-3 Include error description as ProblemDetails.Detail for non-validation problems (REQ-1, REQ-2)

## Checks the factory ran itself
- 56 tests in a sealed container; 56 passed; no new failures vs the base branch
- Acceptance tests were written first, failed on the old code twice, then locked
- ⚠ Single model family: tests written by claude-opus-5-5, code by claude-sonnet-5 (both anthropic). A second-vendor coding runner isn't built yet.
- Review: 0 non-blocking findings
- Security review (OWASP Top 10): nothing found

Cost: $2.24 · Run: `20261003-cancelling-a-completed-appoint-b3d3` · Evidence manifest: `d3c733f5686fa34e8b61b5ab9417934f9f47e4d413ab07a567ed0c26f2e60abb`