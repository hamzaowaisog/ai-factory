# Questions before the spec (round 1)

Run 20261004-post-api-appointments-accepts-557c. Your request:
> POST /api/appointments accepts a second appointment for the same patient that overlaps one they already have with
> another doctor. A patient can't be in two places at once: refuse the overlapping booking with 409 Conflict, the
> same way a doctor's overlapping booking is refused today.
> 

**Q-1** Should the patient overlap rule also apply to other ways of changing an appointment's time (such as rescheduling, updating, or reactivating a cancelled one), or only to POST /api/appointments?
  A. Only POST /api/appointments
  B. Every write path that sets or changes an appointment's time or makes it Scheduled again   ← recommended: 'A patient can't be in two places at once' is a rule about stored data, not about one endpoint.
  (why it matters: Affects which writes are refused across the whole scheduling API.)

**Q-2** Should the database itself enforce the patient rule, or is a check in the application code enough?
  A. Check in the application code only, with the same known race window the doctor check has today
  B. Also add a unique index on (PatientId, StartUtc, EndUtc) and map its violation to 409, mirroring the doctor index (blocks only exact duplicates)   ← recommended: This is the closest match to 'the same way' for doctors, and it needs no change to how transactions work.
  C. Make check-and-insert atomic (for example a serializable transaction or exclusion constraint) for both patient and doctor
  (why it matters: Decides whether a schema migration happens and whether two requests sent at the same moment can still save overlapping rows.)

**Q-3** Some patients may already have overlapping Scheduled appointments saved. What should happen to them?
  A. Leave them as they are; the rule only applies to new bookings   ← recommended: The request only asks to refuse new bookings. If a unique index is added, the migration must still cope with any exact duplicates already stored.
  B. Report them so staff can fix them by hand, but don't change any data
  C. Clean them up automatically before the rule is enforced
  (why it matters: Could mean changing existing appointments, and could make the migration fail.)

**Q-4** If a patient booking is refused in a race (two requests at once), what should the database-error fallback do?
  A. Catch the patient index violation and return 409, the same as the doctor fallback   ← recommended: This keeps the result for patients the same as for doctors.
  B. Do no patient fallback; a violation surfaces as a 500 error
  C. Retry the overlap check after the failure and return 409 if it finds an overlap
  (why it matters: Changes the status code clients see when two bookings are sent at the same time.)

Assumed unless you say otherwise:
- ASM-1: What error code and message should the patient conflict return? → assumed: A new code 'Appointment.PatientConflict' with a message about the patient
- ASM-2: If a booking clashes with both the doctor's and the patient's schedule, which error should be reported? → assumed: The doctor conflict (keep the current check first)
- ASM-3: There are no integration tests for conflicts at all today. Should this change also add a test for the existing doctor-overlap 409? → assumed: Add tests for both the patient-overlap and doctor-overlap 409

Answer with letters or your own words:
  factory answer 20261004-post-api-appointments-accepts-557c a7d96487 Q-1=A Q-2=A Q-3=A Q-4=A
  (use quotes for words: Q-1="only for guest checkouts")

Card hash: a7d96487