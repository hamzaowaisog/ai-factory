# Limit reached: Cost limit reached: $6.11 of $6.00

Run 20261004-post-api-appointments-accepts-557c · spent $6.11 · 29 min active

To continue with a higher limit (suggested):
  factory waive-cap 20261004-post-api-appointments-accepts-557c 31221cfe --cost 16
Or stop here: factory stop 20261004-post-api-appointments-accepts-557c

Card hash: 31221cfe