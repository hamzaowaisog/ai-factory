# Questions before the spec (round 2)

Run 20261004-post-api-appointments-accepts-557c. Your request:
> POST /api/appointments accepts a second appointment for the same patient that overlaps one they already have with
> another doctor. A patient can't be in two places at once: refuse the overlapping booking with 409 Conflict, the
> same way a doctor's overlapping booking is refused today.
> 

**Q-5** The new unique index on (PatientId, StartUtc, EndUtc) would cover cancelled rows too, like the doctor index does. That means a patient could not rebook the exact slot of an appointment they cancelled, even though cancelled appointments should never block a booking. How should the index work?
  A. Filter the unique index to Status = Scheduled only   ← recommended: This is the only option that keeps both earlier answers true: cancelled appointments never block, and the database enforces the rule.
  B. Keep it unfiltered like the doctor index and accept that rebooking an exact cancelled slot is refused
  C. Drop the unique index and rely only on the application check
  (why it matters: Decides which bookings get written or refused with 409.)

**Q-6** Existing data is meant to stay as it is. But if any patient already has two rows with exactly the same start and end, creating the new unique index will fail during migration. What should happen to those rows?
  A. Check for duplicates before migrating, and cancel all but the earliest duplicate in a data step   ← recommended: Without this step the migration can fail in production, and it is the smallest change to existing data.
  B. Make the migration stop with a clear error and fix the data by hand
  C. Use a filtered/partial index so existing duplicates are left out (if the database supports it)
  (why it matters: Could change the status of existing appointment rows.)

**Q-7** When a booking clashes with both the doctor's and the patient's schedules, only the first error reaches the 409. Which check runs first, and what code and message does the patient conflict use?
  A. Doctor check first; patient error uses code "Appointment.PatientConflict" with message "Patient has a conflicting appointment during the requested time"   ← recommended: Keeps what callers see for doctor conflicts today and lets clients tell the two cases apart.
  B. Patient check first; same patient-specific code and message
  C. Reuse code "Appointment.Conflict" with a patient-specific message
  (why it matters: Changes the 409 title clients see.)

Assumed unless you say otherwise:
- ASM-4: Should the new unique patient index replace the existing non-unique IX_Appointments_Patient_StartTime, or be added alongside it? And what should it be named, given that the race-condition fallback matches on the index name? → assumed: Add a new index named IX_Appointments_Patient_TimeRange and keep the existing one
- ASM-5: No integration test covers a conflict today. Should this change add tests? → assumed: Add integration tests for both the patient-overlap and doctor-overlap 409

Answer with letters or your own words:
  factory answer 20261004-post-api-appointments-accepts-557c 15a52f82 Q-5=A Q-6=A Q-7=A
  (use quotes for words: Q-5="only for guest checkouts")

Card hash: 15a52f82